import { API_URL } from "./config.js";
import { obtenerToken, obtenerUsuario } from "./auth.js";

document.addEventListener("DOMContentLoaded", async () => {
    const token = obtenerToken();
    const usuario = obtenerUsuario();

    const params = new URLSearchParams(window.location.search);
    const idexpediente = params.get("exp");

    const select = document.getElementById("selectTipo");
    const btnGenerar = document.getElementById("btnGenerarDoc");

    btnGenerar.addEventListener("click", async () => {
        const tipo = select.value;

        const res = await fetch(`${API_URL}/documentos/generar`, {
            method: "POST",
            headers: {
                "Authorization": `Bearer ${token}`,
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                tipo,
                idexpediente,
                rfc: usuario.rfc
            })
        });

        const data = await res.json();

        if (!res.ok) {
            alert(data.error || "Error al generar documento");
            return;
        }

        alert("Documento generado correctamente");
        location.reload();
    });
});
