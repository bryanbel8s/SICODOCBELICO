import { API_URL } from "./config.js";
import { obtenerToken, obtenerUsuario } from "./auth.js";

document.addEventListener("DOMContentLoaded", async () => {
    const token = obtenerToken();

    if (!token) {
        window.location.href = "login.html";
        return;
    }

    const res = await fetch(`${API_URL}/documentos/mis`, {
        headers: { "Authorization": `Bearer ${token}` }
    });

    const docs = await res.json();
    const container = document.querySelector(".document-buttons");

    container.innerHTML = "";

    docs.forEach(doc => {
        container.innerHTML += `
            <button class="document-btn" data-doc-id="${doc.iddocumento}" data-doc-name="${doc.tipo}">
                ${doc.tipo}
            </button>
        `;
    });

    // CLICK para abrir visor PDF
    container.addEventListener("click", (e) => {
        const boton = e.target.closest(".document-btn");
        if (boton) {
            const params = new URLSearchParams();
            params.append("id", boton.dataset.docId);
            params.append("name", boton.dataset.docName);

            window.location.href = `vistaprev_pdf.html?${params.toString()}`;
        }
    });
});
